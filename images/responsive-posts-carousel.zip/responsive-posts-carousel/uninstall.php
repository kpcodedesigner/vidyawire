<?php

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
        exit;
}

// delete_option( 'wcp_posts_carousel' );

?>